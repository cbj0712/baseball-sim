package com.lsg.baseball.player.dto;

import com.lsg.baseball.player.domain.Player;
import com.lsg.baseball.player.domain.enums.*;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Getter
@NoArgsConstructor
public class PlayerDetailResponse {
    private Long id;
    private String name;
    private LocalDate birthDate;
    private String nationality;
    private Integer uniformNumber;

    private Integer heightCm;
    private Integer weightKg;
    private BodyType bodyType;

    private Position mainPosition;
    private List<Position> subPositions;
    private ThrowHand throwHand;
    private BatHand batHand;
    private ArmSlot armSlot;

    private int condition;
    private int fatigue;
    private int fitness;
    private InjuryStatus injuryStatus;
    private Integer injuryDaysLeft;
    private int satisfaction;
    private int loyalty;

    private int potential;
    private int overall;
    private int stamina;
    private int composure;

    private int hitContact;
    private int hitPower;
    private int plateDiscipline;
    private int baserunning;
    private int fielding;
    private int armStrength;

    private int pitchVelocity;
    private int pitchControl;
    private int pitchStuff;
    private int breakingBall;
    private int pickoff;

    public static PlayerDetailResponse from(Player player) {
        PlayerDetailResponse dto = new PlayerDetailResponse();

        dto.id = player.getId();
        dto.name = player.getName();
        dto.birthDate = player.getBirthDate();
        dto.nationality = player.getNationality();
        dto.uniformNumber = player.getUniformNumber();

        dto.heightCm = player.getHeightCm();
        dto.weightKg = player.getWeightKg();
        dto.bodyType = player.getBodyType();

        dto.mainPosition = player.getMainPosition();
        dto.subPositions = player.getSubPositions();
        dto.throwHand = player.getThrowHand();
        dto.batHand = player.getBatHand();
        dto.armSlot = player.getArmSlot();

        dto.condition = player.getCondition();
        dto.fatigue = player.getFatigue();
        dto.fitness = player.getFitness();
        dto.injuryStatus = player.getInjuryStatus();
        dto.injuryDaysLeft = player.getInjuryDaysLeft();
        dto.satisfaction = player.getSatisfaction();
        dto.loyalty = player.getLoyalty();

        dto.potential = player.getPotential();
        dto.overall = player.getOverall();
        dto.stamina = player.getStamina();
        dto.composure = player.getComposure();

        dto.hitContact = player.getHitContact();
        dto.hitPower = player.getHitPower();
        dto.plateDiscipline = player.getPlateDiscipline();
        dto.baserunning = player.getBaserunning();
        dto.fielding = player.getFielding();
        dto.armStrength = player.getArmStrength();

        dto.pitchVelocity = player.getPitchVelocity();
        dto.pitchControl = player.getPitchControl();
        dto.pitchStuff = player.getPitchStuff();
        dto.breakingBall = player.getBreakingBall();
        dto.pickoff = player.getPickoff();

        return dto;
    }
}
